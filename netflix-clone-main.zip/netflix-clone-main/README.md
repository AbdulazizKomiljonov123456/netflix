# Netflix clone | React JS, Firebase, TMDB API (+Responsive)

## Video tutorial: https://www.youtube.com/watch?v=IIQ3oZ5AqJc

## Demo: https://netflixtutorial.netlify.app/
